package com.insecureshop

import android.app.Application
import android.content.Context
import android.util.Log


class InsecureShopApp : Application() {

    override fun onCreate() {
        super.onCreate()
//        invokePlugins()
    }

    private fun invokePlugins() {

    }


}