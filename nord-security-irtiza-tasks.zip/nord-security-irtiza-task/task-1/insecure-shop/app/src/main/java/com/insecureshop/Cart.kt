package com.insecureshop

data class Cart(var name: String, var url: String, var price: String, var rating: Int)