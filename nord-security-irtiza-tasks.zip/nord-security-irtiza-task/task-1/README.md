# Task 1

## Overview

This folder contains manifest for the task 1.

## Details:

1. I deployed a Gitlab CE instances.
2. Clonsed this [respository](https://github.com/hax0rgb/InsecureShop).
3. I have used following tools:

    a. [Secret Detections](https://github.com/Yelp/detect-secrets).
    b. [Software Composition Analysis SCA](https://github.com/XmirrorSecurity/OpenSCA-cli).
    c. [Static application security Testing](https://docs.sonarsource.com/sonarqube/latest/analyzing-source-code/scanners/sonarscanner/)

4. In the above tools, I was not able to find a failure command (to fail a job in case of issue detection). I have written small python scripts to fail the job. 
5. [These python scripts](https://github.com/aliartiza75/gitlab-sec-pipeline-validators) analyze the results, and raise an exception that causes the jobs to fail.
6. In Gitlab job configuration, i have added a condition `when: on_failure` that only in case of failure the results should be stored as job artifact for further analysis.