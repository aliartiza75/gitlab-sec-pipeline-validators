# Task 2

## Overview

This folder contains manifest for the task 2.

## Details

1. I have used one of my old [respository](https://github.com/aliartiza75/crud-for-iot-devices) for this task. The reason, I used it is because it is 4 years old with alot of issues in it and it is a npm based project.
2. I have used following tools:

    a. [OWASP Dependency check](https://github.com/jeremylong/DependencyCheck).
    b. [Software Composition Analysis SCA](https://docs.snyk.io/)

3. In Github Actions I didn't have to use the and custom scripts becuase both of the above tools have a fail trigger in case of any issues.
4. I also wanted to use snyk in Gitlab but synk was having alot of issues while scanning the gradle, i could have fixed the issue but due to lack of time i opted for other solution.

 


